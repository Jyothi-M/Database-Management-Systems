package com.MoneyManagement.beans;

import java.io.Serializable;

public class TransactionBean implements Serializable{

	public String Amount;
	public String Category;
	public String Date;
	public String Comments;
	public String UserName;
	public String UserGroup;
	
	public TransactionBean(String amount, String category, String date, String comments, String userName,
			String userGroup) {
		super();
		Amount = amount;
		Category = category;
		Date = date;
		Comments = comments;
		UserName = userName;
		UserGroup = userGroup;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserGroup() {
		return UserGroup;
	}
	public void setUserGroup(String userGroup) {
		UserGroup = userGroup;
	}
	public String getAmount() {
		return Amount;
	}
	public void setAmount(String amount) {
		Amount = amount;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}
	@Override
	public String toString() {
		return "TransactionBean [Amount=" + Amount + ", Category=" + Category + ", Date=" + Date + ", Comments="
				+ Comments + ", UserName=" + UserName + ", UserGroup=" + UserGroup + "]";
	}
	
	
	
}
