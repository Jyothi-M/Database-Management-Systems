package com.MoneyManagement.beans;

public class RegistrationBean {
	
	private String Username;
	private String Password;
	private String Email;
	private String ContactNumber;
	private String DateOfBirth;
	private String Gender;
	
	private String firstName;
	private String lastName;
	private String middleName;
	
	private String bankName;
	private String accountType;
	private String bankCode;
	
	public RegistrationBean(String username, String password, String email, String contactNumber, String dateOfBirth,
			String gender, String firstName, String lastName, String middleName, String bankName, String accountType,
			String bankCode) {
		super();
		Username = username;
		Password = password;
		Email = email;
		ContactNumber = contactNumber;
		DateOfBirth = dateOfBirth;
		Gender = gender;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.bankName = bankName;
		this.accountType = accountType;
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getContactNumber() {
		return ContactNumber;
	}
	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}
	public String getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	@Override
	public String toString() {
		return "RegistrationBean [Username=" + Username + ", Password=" + Password + ", Email=" + Email
				+ ", ContactNumber=" + ContactNumber + ", DateOfBirth=" + DateOfBirth + ", Gender=" + Gender
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", middleName=" + middleName + ", bankName="
				+ bankName + ", accountType=" + accountType + ", bankCode=" + bankCode + "]";
	}
}
