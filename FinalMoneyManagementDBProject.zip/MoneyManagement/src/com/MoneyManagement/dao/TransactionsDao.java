package com.MoneyManagement.dao;

import com.MoneyManagemenet.util.DatabaseConnectionUtility;
import com.MoneyManagement.beans.TransactionBean;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionsDao {
	
	public ArrayList<TransactionBean> getTransactionsList(String userName) throws ClassNotFoundException, SQLException{
		
		Connection dbConnection = null;
		Statement statement = null;
		
		ArrayList<TransactionBean> listOfTransactions=new ArrayList<TransactionBean>();

		String selectTableSQL = "SELECT TRANS_ID, USER_ID, CATEGORY_NAME, USER_GROUP_NAME, AMOUNT, TRANS_DATE, COMMENTS from TRANSACTION_DETAILS,CATEGORY_DETAILS,USER_GROUP WHERE USER_ID=(SELECT USER_ID FROM USERS WHERE USERNAME='"+userName+"') and CATEGORY_DETAILS.CATEGORY_ID=TRANSACTION_DETAILS.CATEGORY_ID\r\n" + 
				"and USER_GROUP.USER_GROUP_ID = TRANSACTION_DETAILS.USER_GROUP_ID order by TRANS_DATE";

		try {
			dbConnection = DatabaseConnectionUtility.getConnection();
			statement = dbConnection.createStatement();

			System.out.println(selectTableSQL);

			// execute select SQL stetement
			ResultSet rs = statement.executeQuery(selectTableSQL);

			while (rs.next()) {

				String trnID = rs.getString("TRANS_ID");
				String userID = rs.getString("USER_ID");
				String categoryID = rs.getString("CATEGORY_NAME");
				String userGroupID = rs.getString("USER_GROUP_NAME");
				String amount = rs.getString("AMOUNT");
				String trnDate = rs.getString("TRANS_DATE");
				String comments = rs.getString("COMMENTS");

				TransactionBean Transaction=new TransactionBean(amount,categoryID,trnDate,comments,userName,userGroupID);
				
				listOfTransactions.add(Transaction);				

			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		} finally {

			if (statement != null) {
				statement.close();
			}

			if (dbConnection != null) {
				dbConnection.close();
			}

		}
		return listOfTransactions;

		
		
	}

}
