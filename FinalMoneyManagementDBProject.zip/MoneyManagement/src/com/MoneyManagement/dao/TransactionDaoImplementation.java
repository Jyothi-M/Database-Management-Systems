package com.MoneyManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.MoneyManagemenet.util.DatabaseConnectionUtility;
import com.MoneyManagement.beans.TransactionBean;
public class TransactionDaoImplementation {
	
	public int addTransaction(TransactionBean InsertTrans) throws SQLException,ClassNotFoundException
	{
	Connection con=DatabaseConnectionUtility.getConnection();
	
	String INSERTTABLESQL = "INSERT INTO TRANSACTION_DETAILS"
			+ "(TRANS_ID,USER_ID,AMOUNT,CATEGORY_ID,TRANS_DATE,COMMENTS,USER_GROUP_ID) VALUES"
			+ "(TRANS_ID_SEQ.NEXTVAL,(SELECT USER_ID FROM USERS WHERE USERNAME=?),?,?,TO_DATE(?,'YYYY-MM-DD'),?,?)";

	PreparedStatement psmt=con.prepareStatement(INSERTTABLESQL);
	
	psmt.setString(1,InsertTrans.getUserName());
	psmt.setString(2,InsertTrans.getAmount());
	psmt.setString(3, InsertTrans.getCategory());
	psmt.setString(4, InsertTrans.getDate());
	psmt.setString(5, InsertTrans.getComments());
	psmt.setString(6, InsertTrans.getUserGroup());

	
	int rows=psmt.executeUpdate();
	
	con.close();
    return rows;
	
	}
	

}
