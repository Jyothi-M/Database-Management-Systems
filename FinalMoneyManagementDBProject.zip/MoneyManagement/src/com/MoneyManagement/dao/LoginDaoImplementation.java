package com.MoneyManagement.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.MoneyManagemenet.util.DatabaseConnectionUtility;
import com.MoneyManagement.beans.UserBean;


public class LoginDaoImplementation  {
	public String validateUser(UserBean login)throws ClassNotFoundException,SQLException{
		 String role = null;
	        Connection con = DatabaseConnectionUtility.getConnection();
	 
	        Statement stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT USERNAME,PASSWORD FROM USERS WHERE USERNAME="+"'"+login.getUsername()+"'"+" AND PASSWORD="+"'"+login.getPassword()+"'");
	         System.out.println("In Login DAO: "+login.getUsername()+":"+login.getPassword());
	         
	        if(rs.next()){
	            role=rs.getString("USERNAME");
	            System.out.println("In resultSet Login:"+role);
	        }
	        else{
	            role = "invalid";
	        }
	        return role;	
	}

}
