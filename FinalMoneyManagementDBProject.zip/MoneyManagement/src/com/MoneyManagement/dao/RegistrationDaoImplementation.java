package com.MoneyManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
//import java.util.logging.Level;
import java.util.ArrayList;

import com.MoneyManagemenet.util.DatabaseConnectionUtility;
import com.MoneyManagement.beans.RegistrationBean;
//import com.sun.istack.internal.logging.Logger;
//import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;
import com.MoneyManagement.beans.TransactionBean;

public class RegistrationDaoImplementation {
	public int rows,rows2,rows3;

public int addUser(RegistrationBean registration)throws ClassNotFoundException,SQLException{
	
	Connection con=DatabaseConnectionUtility.getConnection();
	
//	System.out.println("vgs test :"+registration);

	
	String INSERTTABLESQL = "INSERT INTO REGISTRATION_DETAILS"
			+ "(USERNAME,PASSWORD,EMAIL,CONTACT_NUMBER,DATE_OF_BIRTH,GENDER,USER_ID,FIRST_NAME,MIDDLE_NAME,LAST_NAME,AGE) VALUES"
			+ "(?,?,?,?,?,?,USER_ID_SEQ.NEXTVAL,?,?,?,months_between(sysdate,to_date(?,'YYYY-MM-DD'))/12)";
	System.out.println(INSERTTABLESQL);
	
	PreparedStatement psmt=con.prepareStatement(INSERTTABLESQL);
	
	psmt.setString(1, registration.getUsername());
	psmt.setString(2, registration.getPassword());
	psmt.setString(3,registration.getEmail());
	psmt.setString(4,registration.getContactNumber());
//	psmt.setString(5,registration.getDateOfBirth());
	psmt.setString(6,registration.getGender());
	psmt.setString(7,registration.getFirstName());
	psmt.setString(8,registration.getMiddleName());
	psmt.setString(9,registration.getLastName());
	psmt.setString(10,registration.getDateOfBirth()); //YYYY-MM-DD
	
	String INSERTTABLESQL2 = "INSERT INTO USERS"
			+ "(USER_ID,USERNAME,PASSWORD) VALUES"
			+ "(USER_ID_SEQ.CURRVAL,?,?)";
	
	PreparedStatement psmt2=con.prepareStatement(INSERTTABLESQL2);
	
	psmt2.setString(1, registration.getUsername());
	psmt2.setString(2, registration.getPassword());

	
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

//	String d=registration.getDateOfdateBirth();
    try{
        java.util.Date date1=formatter.parse(registration.getDateOfBirth());
        java.sql.Date date=new java.sql.Date(date1.getTime());
        psmt.setDate(5,date);
        
//        System.out.println(registration.getDateOfBirth());
//        System.out.println(date1);
//        System.out.println(date);
    }
         catch (Exception ex) {       
             //Logger.getLogger(RegistrationDaoImplementation.class.getName(), null).log(Level.SEVERE, null, ex);
        	 ex.printStackTrace();
         } 

    String INSERTTABLESQL3 = "INSERT INTO BANK_ACCOUNT"
			+ "(USER_ID,BANK_NAME,ACCOUNT_TYPE,BANK_CODE) VALUES"
			+ "(USER_ID_SEQ.CURRVAL,?,?,"+ Integer.parseInt(registration.getBankCode())+")";
	
	PreparedStatement psmt3=con.prepareStatement(INSERTTABLESQL3);
	
	psmt3.setString(1, registration.getBankName());
	psmt3.setString(2, registration.getAccountType());

    
    rows=psmt.executeUpdate();
    rows2=psmt2.executeUpdate();
    rows3=psmt3.executeUpdate();
    System.out.println("vgs test counts"+rows+" "+rows2+" "+rows3);
  //  con.commit();
    //DatabaseConnectionUtility.commitConnection(con);
    //DatabaseConnectionUtility.closeConnection(con);
    con.close();
    return rows;
}

public ArrayList<String> getUserDetails(String userName) throws ClassNotFoundException, SQLException {
	
	Connection dbConnection = null;
	Statement statement = null;
	
	ArrayList<String> listOfUserData=new ArrayList<String>();

	String selectTableSQL = "select * from REGISTRATION_DETAILS, BANK_ACCOUNT" + 
			" WHERE REGISTRATION_DETAILS.USER_ID=(SELECT USER_ID FROM USERS WHERE USERNAME='"+userName+"') and BANK_ACCOUNT.USER_ID=(SELECT USER_ID FROM USERS WHERE USERNAME='"+userName+"')";

	try {
		dbConnection = DatabaseConnectionUtility.getConnection();
		statement = dbConnection.createStatement();

		System.out.println(selectTableSQL);

		// execute select SQL stetement
		ResultSet rs = statement.executeQuery(selectTableSQL);

		while (rs.next()) {

			String password = rs.getString("PASSWORD");
			String email = rs.getString("EMAIL");
			String contact = rs.getString("CONTACT_NUMBER");
			String dob = rs.getString("DATE_OF_BIRTH");
			String gender = rs.getString("GENDER");
			String firstname = rs.getString("FIRST_NAME");
			String middlename = rs.getString("MIDDLE_NAME");
			String lastname = rs.getString("LAST_NAME");
			String age = rs.getString("AGE");
			
			String bankName = rs.getString("BANK_NAME");
			String accType = rs.getString("ACCOUNT_TYPE");
			String bankCode = rs.getString("BANK_CODE");
			
			
			
			listOfUserData.add("USERNAME : "+userName);
			listOfUserData.add("PASSWORD : "+password);
			listOfUserData.add("EMAIL : "+email);
			listOfUserData.add("CONTACT :"+contact);
			listOfUserData.add("DATE OF BIRTH: "+dob);
			listOfUserData.add("GENDER :"+gender);
			listOfUserData.add("FIRST NAME :"+firstname);
			listOfUserData.add("MIDDLE NAME :"+middlename);
			listOfUserData.add("LAST NAME :"+lastname);
			listOfUserData.add("AGE :"+age);
			listOfUserData.add("BANK NAME :"+bankName);
			listOfUserData.add("ACCOUNT TYPE :"+accType);
			listOfUserData.add("BANK CODE :"+bankCode);

		}

	} catch (SQLException e) {

		System.out.println(e.getMessage());

	} finally {

		if (statement != null) {
			statement.close();
		}

		if (dbConnection != null) {
			dbConnection.close();
		}

	}
	
	return listOfUserData;

	
}

}
