package com.MoneyManagement.services;

import java.sql.SQLException;

import com.MoneyManagement.beans.UserBean;
import com.MoneyManagement.dao.LoginDaoImplementation;
public class LoginService {
public String validateUser(UserBean login)throws ClassNotFoundException,SQLException{
	LoginDaoImplementation loginDaoImplementation=new LoginDaoImplementation();
	return loginDaoImplementation.validateUser(login);
}
}
