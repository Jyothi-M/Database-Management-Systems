package com.MoneyManagement.services;

import java.sql.SQLException;

import com.MoneyManagement.beans.RegistrationBean;
import com.MoneyManagement.dao.RegistrationDaoImplementation;


public class RegistrationService {
	
     public int addUser(RegistrationBean registration)throws ClassNotFoundException,SQLException{
    	 RegistrationDaoImplementation registrationDaoImplementation=new RegistrationDaoImplementation();
    	    return registrationDaoImplementation.addUser(registration);
     }
	
	
}
