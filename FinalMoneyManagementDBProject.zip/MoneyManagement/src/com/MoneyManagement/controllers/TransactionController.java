package com.MoneyManagement.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MoneyManagement.beans.TransactionBean;
import com.MoneyManagement.dao.TransactionDaoImplementation;
public class TransactionController extends HttpServlet {
	public void init()
	{
		
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		PrintWriter out=response.getWriter();	
		
		HttpSession session=request.getSession();
		String userName=(String) session.getAttribute("userName");
		
		String amount=request.getParameter("Amount");
		String category=request.getParameter("Category");
		String date=request.getParameter("Date");
		String purpose=request.getParameter("Purpose");
		String userGroup=request.getParameter("userGroup");

		
		TransactionBean Transaction=new TransactionBean(amount,category,date,purpose,userName,userGroup);
		
		TransactionDaoImplementation TrnDao=new TransactionDaoImplementation();
		int rowsInserted=0;
		try {
			rowsInserted = TrnDao.addTransaction(Transaction);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		if(rowsInserted!=0){
			
			RequestDispatcher rd=request.getRequestDispatcher("TrnsubmissionSuccess.jsp");
			rd.forward(request, response);
		}
		else{
			
			RequestDispatcher rd=request.getRequestDispatcher("TrnsubmissionFail.jsp");
			rd.forward(request, response);
		}
		
		System.out.println(Transaction);
		
		
	}

}
