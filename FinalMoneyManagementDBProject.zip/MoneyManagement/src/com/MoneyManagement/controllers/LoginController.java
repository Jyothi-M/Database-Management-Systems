package com.MoneyManagement.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MoneyManagement.beans.RegistrationBean;
import com.MoneyManagement.beans.UserBean;
import com.MoneyManagement.services.LoginService;

public class LoginController extends HttpServlet {
	public void init(){
		
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String userName=request.getParameter("UserName");
		String password=request.getParameter("Password");
		String role="";
		
		UserBean loginInfo=new UserBean(userName,password);
		
		LoginService loginService=new LoginService();
//		
		try{
			role=loginService.validateUser(loginInfo);
			System.out.println("In login controller:"+role);
		}
		 catch(ClassNotFoundException ce){
	            ce.printStackTrace();
	            // append exception message to log file
	        }
	        catch(SQLException se){
	            se.printStackTrace( );
	            // append exception message to log file
	        }
		if(role.equalsIgnoreCase("invalid")){
			
			RequestDispatcher rd=request.getRequestDispatcher("loginFailed.jsp");
			rd.forward(request, response);
		}
		else {
			HttpSession session=request.getSession();
			session.setAttribute("userName", userName);
			
			RequestDispatcher rd=request.getRequestDispatcher("homepage.jsp");
			rd.forward(request, response);
			
		}
//		if(role.equalsIgnoreCase("user")){
//			HttpSession session=request.getSession();
//			session.setAttribute("userName", userName);
//			
//			RequestDispatcher rd=request.getRequestDispatcher("userHomePage.jsp");
//			rd.forward(request, response);
//		}
//		if(role.equalsIgnoreCase("invalid")){
//			RequestDispatcher rd=request.getRequestDispatcher("invalidPage.jsp");
//			rd.forward(request, response);
//		}
	}
	public void destroy(){
		
	}

}
