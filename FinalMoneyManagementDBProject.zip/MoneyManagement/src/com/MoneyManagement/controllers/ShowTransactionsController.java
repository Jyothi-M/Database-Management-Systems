package com.MoneyManagement.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MoneyManagement.beans.TransactionBean;
import com.MoneyManagement.dao.TransactionDaoImplementation;
import com.MoneyManagement.dao.TransactionsDao;
public class ShowTransactionsController extends HttpServlet {
	public void init()
	{
		
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		PrintWriter out=response.getWriter();	
		
		HttpSession session=request.getSession();
		String userName=(String) session.getAttribute("userName");
		
		ArrayList<TransactionBean> listOfTransactions=new ArrayList<TransactionBean>();
		TransactionsDao trnDao=new TransactionsDao();
		try {
			listOfTransactions=trnDao.getTransactionsList(userName);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(listOfTransactions);
		
		if(listOfTransactions!=null){
			
//			HttpSession session1=request.getSession();
			request.setAttribute("listOfTransactions1", listOfTransactions);
			
			RequestDispatcher rd=request.getRequestDispatcher("ShowRecentTransactions.jsp");
			rd.forward(request, response);
		}
		else{
			
			RequestDispatcher rd=request.getRequestDispatcher("submissionFailure.jsp");
			rd.forward(request, response);
		}
		
	}

}
