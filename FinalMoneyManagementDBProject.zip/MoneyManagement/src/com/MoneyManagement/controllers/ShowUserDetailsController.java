package com.MoneyManagement.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MoneyManagement.beans.TransactionBean;
import com.MoneyManagement.dao.RegistrationDaoImplementation;
import com.MoneyManagement.dao.TransactionDaoImplementation;
import com.MoneyManagement.dao.TransactionsDao;
public class ShowUserDetailsController extends HttpServlet {
	public void init()
	{
		
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		PrintWriter out=response.getWriter();	
		
		HttpSession session=request.getSession();
		String userName=(String) session.getAttribute("userName");
		
		ArrayList<String> listOfUserData=new ArrayList<String>();
		RegistrationDaoImplementation regDao=new RegistrationDaoImplementation();
		try {
			listOfUserData=regDao.getUserDetails(userName);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(listOfUserData);
		
		if(listOfUserData!=null){
			
//			HttpSession session1=request.getSession();
			request.setAttribute("listOfUserData1", listOfUserData);
			
			RequestDispatcher rd=request.getRequestDispatcher("ShowUserData.jsp");
			rd.forward(request, response);
		}
		else{
			
			RequestDispatcher rd=request.getRequestDispatcher("submissionFailure.jsp");
			rd.forward(request, response);
		}
		
	}

}

