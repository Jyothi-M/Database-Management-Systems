package com.MoneyManagement.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MoneyManagement.beans.RegistrationBean;
import com.MoneyManagement.services.RegistrationService;


public class RegistrationController extends HttpServlet{
public void init(){
	
}
public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
	int rowsInserted=0;
	PrintWriter out=response.getWriter();
	
	String username=request.getParameter("Username");
	String password=request.getParameter("Password");
	String dateOfBirth=request.getParameter("Birthday");
	String emailId=request.getParameter("Email");
	String contactNo=request.getParameter("contactNo");
	String gender=request.getParameter("Gender");
	String firstName=request.getParameter("firstName");
	String lastName=request.getParameter("middleName");
	String middleName=request.getParameter("lastName");
	String bankName=request.getParameter("bankName");
	String accountType=request.getParameter("accountType");
	String bankCode=request.getParameter("bankCode");

	System.out.println("vgs test :"+dateOfBirth);
	
	RegistrationBean registration=new RegistrationBean(username,password,emailId,contactNo,dateOfBirth,gender,firstName,middleName,lastName,bankName,accountType,bankCode);
	
	RegistrationService registrationService=new RegistrationService();
	
	try{
		
	 rowsInserted=registrationService.addUser(registration);
	 
	}catch(ClassNotFoundException ce){
		ce.printStackTrace();
	}catch(SQLException se){
		se.printStackTrace();
	}
if(rowsInserted!=0){
	
	RequestDispatcher rd=request.getRequestDispatcher("submissionSuccess.jsp");
	rd.forward(request, response);
}
else{
	
	RequestDispatcher rd=request.getRequestDispatcher("submissionFailure.jsp");
	rd.forward(request, response);
}
}
public void destroy(){
}
}
